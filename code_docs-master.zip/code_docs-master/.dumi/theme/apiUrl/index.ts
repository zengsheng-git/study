enum apiURL {
  XCAPI = "https://api.xsot.cn/sentence/", // 星辰api
  QNYYAPI = "https://v1.hitokoto.cn/" , // 青柠起始页一言api
}

export default apiURL
